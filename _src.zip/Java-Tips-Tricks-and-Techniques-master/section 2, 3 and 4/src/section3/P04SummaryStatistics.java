package section3;

public class P04SummaryStatistics {

    // Please see the StreamStatisticsDemo.java example code
}
