module download {
    exports java12.section5.download;
    requires java.net.http;
}